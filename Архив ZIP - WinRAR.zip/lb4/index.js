exports.fibun = function () {
    var fib = [0, 1]; // Initialize array!
    for (i = 1; i <= 10; i++) {
        fib[1]=1
        if (i>1){
          fib[i] = fib[i - 2] + fib[i - 1];  
        }
        
        console.log('ss1',i);
        console.log(fib[i]);
    }
}

