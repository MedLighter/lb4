const a = require("proectlb45");
a.fibun();